// WARNING: this file is auto generated, any changes will be lost
import { createDesignComponent, CanvasStore } from "framer"
const canvas = CanvasStore.shared(); // CANVAS_DATA;
export const Component = createDesignComponent<{parentSize?:{width:number|string,height:number|string},width?:number|string,height?:number|string,Title?:string,Left?:string,Center?:string,Right?:string}>(canvas, "id_Dg68Q38E3", {Title:"string",Left:"string",Center:"string",Right:"string"}, 375,375);
export const DitherDemo = createDesignComponent<{parentSize?:{width:number|string,height:number|string},width?:number|string,height?:number|string,Title?:string,Left?:string,Center?:string,Right?:string}>(canvas, "id_eKXVTQkyy", {Title:"string",Left:"string",Center:"string",Right:"string"}, 375,375);
export const DitherDemo_1 = createDesignComponent<{parentSize?:{width:number|string,height:number|string},width?:number|string,height?:number|string,Title?:string,Left?:string,Center?:string,Right?:string}>(canvas, "id_kXSNL0AWv", {Title:"string",Left:"string",Center:"string",Right:"string"}, 375,375);
