import * as React from "react"
import { Override, Data } from "framer"
import { navigate } from "./Navigation"

// state

const appState = Data({
    selected: null,
    results: [],
})

// Navigation

const showLogin = () => {
    navigate({
        currentPage: 0,
        pageTitle: "Log In",
        backAction: null,
    })
}

const showAll = () => {
    navigate({
        currentPage: 1,
        pageTitle: "All",
        backAction: null,
    })
}

const showDetail = () => {
    navigate({
        currentPage: 2,
        pageTitle: "Detail",
        backAction: showAll,
    })
}

// Data

const authenticate = async () => {
    // if (navigator.userAgent.includes("FramerX")) {
    //     skipAuth()
    //     return
    // }

    window.addEventListener(
        "message",
        function(event) {
            var hash = JSON.parse(event.data)
            if (hash.type == "access_token") {
                console.log("has access token", hash.access_token)
            }
        },
        false
    )

    window.open("http://localhost:8888/login")
    console.log("got it!")

    showAll()
}

const skipAuth = async () => {
    // fetch data
    // loadGists(gists)
    showAll()
}

const loadAll = async data => {
    // set data to state
    showAll()
}

const loadDetail = async gist => {
    // fetch data

    showDetail()
}

// authenticate

export const AuthenticateButton: Override = () => {
    return {
        onTap: authenticate,
    }
}

export const SkipAuthButton: Override = () => {
    return {
        onTap: skipAuth,
    }
}

// Overrides
