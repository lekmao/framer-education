import * as React from "react"
import { Override, Data } from "framer"
import { navigate } from "./Navigation"

const { search } = window.location

// state

const appState = Data({
    accessToken: "",
    selected: null,
    results: [],
})

// Navigation

const showLogin = () => {
    navigate({
        currentPage: 0,
        pageTitle: "Log In",
        backAction: null,
    })
}

const showAll = () => {
    navigate({
        currentPage: 1,
        pageTitle: "All",
        backAction: null,
    })
}

const showDetail = () => {
    navigate({
        currentPage: 2,
        pageTitle: "Detail",
        backAction: showAll,
    })
}

// Data

const authenticate = async () => {
    window.location.assign("http://localhost:8888/login")
}

const skipAuth = async () => {
    // fetch data
    // loadGists(gists)
    showAll()
}

const loadAll = async () => {
    // set data to state

    const res = await fetch("https://api.spotify.com/v1/me", {
        headers: {
            Authorization: "Bearer " + appState.accessToken,
        },
    })
    const json = await res.json()
    console.log(json)

    showAll()
}

const loadDetail = async gist => {
    // fetch data

    showDetail()
}

// authenticate

export const AuthenticateButton: Override = () => {
    return {
        onTap: authenticate,
    }
}

export const SkipAuthButton: Override = () => {
    return {
        onTap: skipAuth,
    }
}

// Overrides

if (search && search.includes("access_token")) {
    appState.accessToken = search.split("?access_token=")[1]
    loadAll()
    console.log("have access token", appState.accessToken)
}
